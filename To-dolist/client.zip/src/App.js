import React from 'react';
import { BrowserRouter, Routes, Route, Form } from "react-router-dom";
import 'bootstrap/dist/css/bootstrap.min.css';
import Login from './components/Login';
import SignUp from './components/SignUp';
import TodoListPage from './components/TodoListPage';
import PrivateRouter from './components/PrivateRouter';
import EntranceRouter from './components/EntranceRouter';
import FormPage from './components/Form';

function App() {
  return (
    <>
      <BrowserRouter>
        <Routes>
          <Route path="/" element={
            <EntranceRouter>
              <Login />
            </EntranceRouter>
          } />
          <Route path="/signup" element={
            <EntranceRouter>
              <SignUp />
            </EntranceRouter>
          } />
          <Route path="/todolist" element={
            <PrivateRouter>
              <TodoListPage />
            </PrivateRouter>
          } />
          <Route path="/form" element={
            <PrivateRouter>
              <FormPage />
            </PrivateRouter>
          } />
        </Routes>
      </BrowserRouter>
    </>
  );
}

export default App;
