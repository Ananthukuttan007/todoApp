import React from 'react'
import { useNavigate } from 'react-router-dom';
import Container from 'react-bootstrap/Container';
import Navbar from 'react-bootstrap/Navbar';
import NavDropdown from 'react-bootstrap/NavDropdown';

function NavBarFile() {
    const navigate = useNavigate()
    const Logout = (e) => {
        e.preventDefault();
        localStorage.clear();
        navigate('/')
    }
    let userName = localStorage.getItem('userName')
    return (
        <Navbar bg="light" expand="lg">
            <Container>
                <Navbar.Brand href="#home">To-Do-List</Navbar.Brand>
                <NavDropdown title={userName.split("@")[0]} id="basic-nav-dropdown">
                    <NavDropdown.Item href="#action/3.1" onClick={Logout}>Logout</NavDropdown.Item>
                </NavDropdown>
            </Container>
        </Navbar >
    )
}

export default NavBarFile